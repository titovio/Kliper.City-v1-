# Kliper.City: задачи для отдельных рабочих чатов

Дата: 2026-07-06.

Назначение: держать отдельные задачи для будущих чатов так, чтобы каждый чат мог взять одну зону, не мешать другим и не трогать `js/app.js` без отдельного решения.

## Правило работы

Каждый чат перед стартом читает:

- `AGENTS.md`
- `docs/PROJECT_INDEX.md`
- `docs/CHAT_OWNERSHIP.md`
- свой раздел из `docs/WORKSTREAM_PROMPTS.md`
- эту очередь задач

Если задача требует `js/app.js`, чат не правит его сам. Он фиксирует причину и возвращает задачу в Architect / Main.

## P0 / P1: ближайшие задачи

| ID | Чат | Приоритет | Задача | Что проверить | Ограничения |
|---|---|---|---|---|---|
| QA-001 | Regression QA | P0 | Пройти полный smoke v1 после последних правок | главная, застройщики, новостройки, готовые ЖК, бизнес, профиль, stories, dark, mobile | не менять код |
| QA-002 | Regression QA | P1 | Отдельно проверить зависания/подвисания после переключений | stories scroll, фильтры, view grid/list/map, переходы карточка -> назад | фиксировать сценарий воспроизведения |
| OBJ-001 | Object Pages | P1 | Проверить большие страницы ЖК и застройщика | открытие, `#card`, кнопка назад, related cards, modals, dark/mobile | не трогать каталог и фильтры |
| OBJ-002 | Object Pages | P1 | Разделить список дефектов object pages на точечные CSS/JS и legacy-route | что можно чинить в `js/pages/object/*`, что требует `js/app.js` | `js/app.js` только через Architect |
| CAT-001 | Catalog Core | P1 | Довести карточные actions до единого поведения | лайк, подписка, рецензия, `aria-pressed`, localStorage, профиль | не менять фильтры и stories |
| CAT-002 | Catalog Core | P1 | Разобрать list-view trap | после list-view должны оставаться способы вернуться в grid/map/sort | вероятно требует legacy/app решения |
| FIL-001 | Filters System | P1 | Стабилизировать фильтры всех каталогов | новостройки, готовые ЖК, бизнес, selected tags, reset, dark/mobile | не менять карточки |
| FIL-002 | Filters System | P1 | Проверить, что старые слои фильтров не всплывают | старый placeholder, старая подложка, hidden source, selected tags | не подключать отключенные fast layers |
| BUS-001 | Business | P1 | Финальная проверка бизнес-раздела | фильтры, selected tags после счетчика, reset, grid/list/map, dark theme | не менять shared residential state |
| STO-001 | Stories & Motion | P1 | Проверить state machine stories | большие по умолчанию, маленькие при скролле вниз, первое/второе движение вверх, раскрытие третьим upward intent | без Motion до стабильности |
| STO-002 | Stories & Motion | P1 | Найти источник визуального наложения колец stories | сегментное кольцо, цветной legacy-слой, белая рябь, dark/light | не менять размеры без задачи |
| MOT-001 | Stories & Motion | P2 | Подготовить один motion-layer без наложения анимаций | только opacity/transform, reduced-motion, без width/height/layout анимаций | не добавлять новые зависимости |
| VIS-001 | Visual System | P1 | Dark theme audit | фильтры, empty-state, selected tags, бизнес-контейнер, object pages | JS не менять |
| VIS-002 | Visual System | P2 | Единая визуальная сетка desktop/mobile | отступы, размеры stories, карточки 4 в ряд, кнопки действий | не менять данные и логику |
| PRO-001 | Profile Social | P1 | Проверить профиль пользователя как v1-витрину | избранное, подписки, рецензии, лента, друзья/чаты визуально | backend не имитировать |
| CAB-001 | Company Cabinet | P1 | Спроектировать кабинет компании для v1 | route, блоки, документы, чат, заявки, предложения, связь с публичной страницей | сначала документация, потом код |
| AUTH-001 | Backend/Auth | P2 | Подготовить требования к авторизации | пользователь, застройщик, роли, localStorage -> backend migration | реализация в конце v1 |
| MOB-001 | Mobile QA | P1 | Мобильная приемка после каждого крупного блока | 390px, 430px, overflow, тапы, stories, фильтры, карточки | сначала отчет |

## Третья волна: после кабинета компании

Эта волна актуальнее старого списка выше. Ее цель - принять v1 после внедрения кабинета компании и не запускать хаотичные правки.

| ID | Чат | Приоритет | Задача | Что проверить / сделать | Ограничения |
|---|---|---|---|---|---|
| QA-003 | Regression QA | P0 | Полный smoke после `Company Cabinet v1` | главная, застройщики, новостройки, готовые ЖК, бизнес, профиль, кабинет компании, stories, dark, mobile, консоль | сначала отчет, код менять только при явном P0/P1 |
| MOB-003 | Mobile QA | P1 | Мобильная приемка v1 после кабинета | 390px и 430px: верхняя панель, stories, фильтры, карточки, бизнес, профиль, кабинет компании, отсутствие horizontal overflow | не менять desktop |
| CAB-002 | Company Cabinet | P1 | Приемка и доводка кабинета компании v1 | desktop/mobile/dark, все 32 застройщика, fallback для компаний без mock-данных, связь с публичной страницей | без backend/auth, без CRM, без `js/app.js` |
| VIS-003 | Visual System | P1 | Визуальная приемка v1 после кабинета | единая плотность, фильтры, selected tags, stories-кольца, dark theme, кабинет компании в общем стиле | JS-логику не менять |
| AUTH-002 | Backend/Auth | P1 | Требования к будущей авторизации и ролям | пользователь, компания, застройщик, `company_owner`, `manager`, `editor`, разделение профиля и кабинета, миграция localStorage | backend не реализовывать сейчас |

## Тарифы размещения

| ID | Чат | Приоритет | Задача | Что проверить / сделать | Ограничения |
|---|---|---|---|---|---|
| BILL-001 | Architect / Main | P1 | Зафиксировать модель тарифов размещения | планы, цены, лимиты карточек, годовой бонус, доп. карточка, v1/v2 границы | не реализовывать оплату |
| CAB-003 | Company Cabinet | P1 | Добавить блок `Тариф и лимиты` в кабинет компании | текущий тариф, лимит карточек, использовано, CTA на тарифы | без backend/auth и CRM |
| VIS-004 | Visual System | P1 | Сделать визуальную страницу тарифов | route `#business-pricing`, desktop/mobile/dark, карточки тарифов | не менять JS-логику каталога |
| AUTH-003 | Backend/Auth | P1 | Описать billing/auth требования | plan, subscription, limits, addons, roles, API candidates | backend не реализовывать сейчас |
| QA-004 | Regression QA | P1 | Smoke после внедрения тарифов | кабинет, pricing route, возврат в кабинет, каталог, консоль | код менять только при явном дефекте |
| MOB-004 | Mobile QA | P1 | Mobile-проверка тарифов | 390px/430px, pricing cards, CTA, cabinet block, overflow | не менять desktop |

## Backend/Auth contracts

| ID | Чат | Приоритет | Задача | Что проверить / сделать | Ограничения |
|---|---|---|---|---|---|
| AUTH-004 | Backend/Auth | P1 | Собрать единый backend/auth контракт v1 | user/company/admin роли, сущности, API, billing, CRM, social, migration localStorage | backend не реализовывать в этой задаче |
| AUTH-005 | Backend/Auth | P1 | Подготовить первый backend implementation brief | выбран read-only auth/company/billing slice, endpoints, данные, проверки доступа, migration preview | backend не реализовывать в этой задаче |
| AUTH-006 | Backend/Auth | P1 | Спроектировать backend storage/schema plan | таблицы, индексы, seed/import, связи с текущими data-файлами | backend не реализовывать в этой задаче |
| AUTH-007 | Backend/Auth + Frontend Integration | P1 | Спроектировать frontend API adapter с mock fallback | как статический frontend вызывает backend при наличии URL и сохраняет текущий mock режим без backend | не подключать backend-код без отдельной реализации |
| AUTH-008 | Backend/Auth | P1 | Подготовить backend stack decision checklist | DB, hosting, auth/session, provider choices, dev/prod strategy | перед написанием backend-кода |
| AUTH-009A | Backend/Auth | P1 | Подготовить API mock server contract and sample responses | health, me, billing plans, company cabinet, subscription, migration preview | без реального backend и без интеграции в сайт |
| AUTH-009 | Backend/Auth | P1 | Реализовать первый read-only backend slice | только после выбора стека и/или AUTH-009A | не начинать без решения владельца/стека |
| AUTH-010 | Frontend Integration | P1 | Реализовать skeleton frontend API adapter с disabled-by-default mock fallback | `js/api/*`, auth-state, pricing/cabinet adapter hooks | done, без реального backend, не трогать `js/app.js` |
| AUTH-011 | Frontend Integration + QA | P1 | Принять adapter skeleton и подготовить mock server/dev toggle | disabled mode, mock fallback, cabinet/pricing data-api-source, 401/403/404 rules | done, backend не включается по умолчанию |
| AUTH-012 | Backend/Auth | P1 | Выбрать backend stack и начать real read-only backend slice | framework, DB, cookie sessions, seed/import, health/me/billing/cabinet | done: stack decision accepted, backend code отдельно |
| AUTH-013 | Backend/Auth | P1 | Подготовить backend scaffold plan and file boundary | `backend/`, package scripts, Prisma folders, module boundaries, .env.example | не устанавливать зависимости без явного старта backend-кода |

## UX-005: site layout and usability audit wave

| ID | Чат | Приоритет | Задача | Что проверить | Ограничения |
|---|---|---|---|---|---|
| UXQA-001 | Regression QA | P1 | Общий smoke удобства и технических ошибок | desktop routes, console/page errors, overflow, navigation, dark/light | отчет без правок |
| UXVIS-001 | Visual System | P1 | Визуальная иерархия и подсветки | активные состояния, плотность, сетка, spacing, контраст | JS не менять |
| UXMOB-001 | Mobile QA | P1 | Мобильная проверка удобства | 390/430px, тапы, sticky/overlay, overflow, карточки, фильтры | desktop не менять |
| UXFIL-001 | Filters System | P1 | Проверка фильтров и старых слоев | dropdowns, selected tags, reset, old placeholders, dark/mobile | карточки не менять |
| UXSTO-001 | Stories & Motion | P1 | Stories layout/state audit | кольца, большие/малые состояния, viewer, scroll/open, layers | без новых анимаций |
| UXCAT-001 | Catalog Core | P1 | Каталожные карточки и controls | карточки, action buttons, grid/list/map, статусы, подсветки | фильтры не менять |
| UXOBJ-001 | Object Pages | P1 | Большие страницы ЖК/застройщика | tabs, modals, back, CTA, related blocks, dark/mobile | каталог не менять |
| UXBUS-001 | Business | P1 | Бизнес-раздел | фильтры, карточки, виды, selected tags, empty states | не смешивать residential state |
| UXPRO-001 | Profile Social | P1 | Профиль пользователя | избранное, подписки, рецензии, лента, social blocks | backend не имитировать |
| UXCAB-001 | Company Cabinet | P1 | Кабинет компании и тарифы | dashboard, panels, CTA, tariffs route, dark/mobile | без backend/auth |

## Задачи, которые нельзя делать вслепую

| ID | Почему осторожно | Что нужно перед работой |
|---|---|---|
| APP-001 | `js/app.js` legacy/generated держит основной SPA-каркас | отдельное решение Architect / Main и regression до/после |
| ROUTE-001 | `#card=...` общий для профиля, ЖК и застройщика | карта сценариев и тесты возврата |
| MOTION-LEGACY-001 | Motion и scroll могут создавать наложение listeners/animations | audit listeners/transitions и reduced-motion |
| FILTER-LEGACY-001 | старые filter layers уже всплывали после скрытия | точный поиск источника и проверка DOM после кликов |

## Что отдавать новому чату

1. Архив `kliper-city-docs-package.zip`.
2. Роль из `docs/WORKSTREAM_PROMPTS.md`.
3. Один ID задачи из этой очереди.
4. Запрет на соседние зоны.
5. Требование вернуть отчет: измененные файлы, проверки, остаточные риски.
