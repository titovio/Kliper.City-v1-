# Kliper.City: реестр рабочих чатов

Дата запуска первой волны: 2026-07-06.

Этот документ фиксирует, какие рабочие чаты созданы в Codex и какую задачу они выполняют. Главный управляющий чат: **Architect / Main**.

## Правило координации

1. Все рабочие чаты сначала делают аудит без правки кода.
2. Исправления выдаются только после приемки отчета в Architect / Main.
3. Если задача затрагивает больше одной зоны, решение принимает Architect / Main.
4. `js/app.js` не редактировать без отдельного решения.
5. Результаты значимых проверок фиксировать в `docs/CHANGE_LOG.md` или отдельном отчете в `docs/`.
6. Приемка отчетов идет по `docs/REPORT_INTAKE_PROTOCOL.md`.

## Первая волна

| Роль | Thread ID | Статус | Первая задача |
|---|---|---|---|
| Regression QA | `019f345b-1bb7-77f1-9e03-3befa5fb2330` | второе задание выдано | `QA-001`, `QA-002`: полный smoke v1 и проверка подвисаний |
| Assets/Data Cleanup | `019f345b-94bb-72a3-860b-48c540c0dfa4` | второе задание выдано | `A-004`: план локализации бизнес-галерей и оставшихся внешних ресурсов |
| Filters System | `019f345b-f5d3-78c3-af1e-33da1b8dea52` | второе задание выдано | `FIL-001`, `FIL-002`: patch plan стабилизации фильтров и старых слоев |
| Visual System | `019f345c-4f7f-7fc1-9f23-d5bc823aa36b` | второе задание выдано | `VIS-001`, `VIS-002`: dark theme и единая визуальная сетка |
| Stories & Motion | `019f345c-c40a-7411-915f-46b39b641cac` | второе задание выдано | `STO-001`, `STO-002`, `MOT-001`: state machine, кольца, motion-layer plan |

## Порядок чтения результатов

1. Regression QA.
2. Assets/Data Cleanup.
3. Filters System.
4. Visual System.
5. Stories & Motion.

## Вторая волна

| Роль | Thread ID | Статус | Первая задача |
|---|---|---|---|
| Object Pages | `019f34e5-4692-7311-8406-a76a0e421a85` | запущен | `OBJ-001`, `OBJ-002`: большие страницы ЖК/застройщика, route, назад, modals, dark/mobile |
| Catalog Core | `019f34e5-8bc6-7b90-aad9-37a196dc13cc` | запущен | `CAT-001`, `CAT-002`: actions карточек и list-view trap |
| Business | `019f34e5-d196-7e63-81e7-297c69bce95d` | запущен | `BUS-001`: бизнес-фильтры, selected tags, reset, виды, dark/mobile |
| Profile Social | `019f34e6-2191-7541-8b80-a274fc63a417` | запущен | `PRO-001`: профиль Марии, избранное, подписки, рецензии, route-state |
| Company Cabinet | `019f34e6-78a5-7910-a7af-d1c5ee6a0241` | запущен | `CAB-001`: проектирование кабинета компании для v1 |
| Mobile QA | `019f34e6-c5f1-7682-8fbb-ff5ad174e196` | запущен | `MOB-001`: мобильная приемка 390px/430px |

## Приемка второй волны

Первые отчеты второй волны приняты в Architect / Main.

Закрыто первым safe-fix batch:

- `BUS-002`: business selected-tags/reset сохраняются после `grid/list/map`;
- `OBJ-003`: `Все рецензии` открывает правильную модалку;
- `R-006`: object -> profile очищает stale hash/class;
- `MOB-002`: mobile object page не попадает под верхний header.

Закрыто вторым safe-fix batch:

- `OBJ-004`: `Назад` с ЖК, открытого из каталога, возвращает в исходный каталог, а не на застройщика;
- `CAT-003`: после residential list-view остаются controls `grid/list/map/sort`.

Дополнительно закрыто:

- `CAB-001`: создан v1 UI-экран кабинета компании через `#company-cabinet=developerId` без backend/auth и без правки `js/app.js`.

## Пока не запускать

| Роль | Причина |
|---|---|
| Backend/Auth | Реализацию запускать после принятия `AUTH_004_BACKEND_AUTH_CONTRACTS_V1.md` и отдельного implementation brief |

## Третья волна

Актуальные задачи после внедрения `Company Cabinet v1`:

| Роль | Статус | Задача |
|---|---|---|
| Regression QA | выполнено в Architect / Main | `QA-003`: полный smoke после кабинета компании, отчет `QA_003_REGRESSION_REPORT.md` |
| Mobile QA | выполнено в Architect / Main | `MOB-003`: мобильная приемка v1 после кабинета, отчет `MOB_003_MOBILE_QA_REPORT.md` |
| Company Cabinet | выполнено в Architect / Main | `CAB-002`: приемка кабинета компании v1, отчет `CAB_002_COMPANY_CABINET_QA.md` |
| Visual System | выполнено в Architect / Main | `VIS-003`: визуальная приемка v1 после кабинета, отчет `VIS_003_VISUAL_ACCEPTANCE.md` |
| Backend/Auth | требования оформлены | `AUTH-002`: требования к авторизации, ролям и миграции localStorage, документ `AUTH_002_BACKEND_AUTH_REQUIREMENTS.md` |

## Тарифы размещения

| Роль | Статус | Задача |
|---|---|---|
| Architect / Main | выполнено | `BILL-001`: модель тарифов размещения, документ `BILL_001_PRICING_MODEL.md` |
| Company Cabinet | выполнено | `CAB-003`: блок `Тариф и лимиты` в кабинете компании |
| Visual System | выполнено | `VIS-004`: route `#business-pricing` и визуальная страница тарифов |
| Backend/Auth | требования оформлены | `AUTH-003`: billing/auth требования, документ `AUTH_003_BILLING_REQUIREMENTS.md` |
| Regression QA | выполнено в Architect / Main | `QA-004`: smoke после внедрения тарифов, отчет `QA_004_PRICING_REGRESSION_REPORT.md` |
| Mobile QA | выполнено в Architect / Main | `MOB-004`: mobile-проверка тарифов, отчет `MOB_004_PRICING_MOBILE_QA.md` |

## Backend/Auth contracts

| Роль | Статус | Задача |
|---|---|---|
| Backend/Auth | контракт оформлен | `AUTH-004`: единый backend/auth контракт v1, документ `AUTH_004_BACKEND_AUTH_CONTRACTS_V1.md` |
| Backend/Auth | brief оформлен | `AUTH-005`: первый backend implementation brief, документ `AUTH_005_BACKEND_IMPLEMENTATION_BRIEF.md` |
| Backend/Auth | storage plan оформлен | `AUTH-006`: storage/schema plan, документ `AUTH_006_STORAGE_SCHEMA_PLAN.md` |
| Backend/Auth + Frontend Integration | adapter plan оформлен | `AUTH-007`: frontend API adapter с mock fallback, документ `AUTH_007_FRONTEND_API_ADAPTER_PLAN.md` |
| Backend/Auth | stack checklist оформлен | `AUTH-008`: backend stack decision checklist, документ `AUTH_008_BACKEND_STACK_DECISION_CHECKLIST.md` |
| Backend/Auth | mock API contract оформлен | `AUTH-009A`: API mock server contract and sample responses, документ `AUTH_009A_API_MOCK_SERVER_CONTRACT.md` |
| Backend/Auth | заблокировано до решения | `AUTH-009`: первый read-only backend slice |
| Frontend Integration | skeleton реализован | `AUTH-010`: frontend API adapter подключен, disabled by default, документ `AUTH_010_FRONTEND_API_ADAPTER_SKELETON.md` |
| Frontend Integration + QA | выполнено | `AUTH-011`: adapter acceptance, dev-toggle и mock server, документ `AUTH_011_ADAPTER_ACCEPTANCE_AND_DEV_TOGGLE.md` |
| Backend/Auth | stack decision принято | `AUTH-012`: Node/Fastify + PostgreSQL + Prisma + httpOnly sessions, документ `AUTH_012_BACKEND_STACK_DECISION.md` |
| Backend/Auth | следующий кандидат | `AUTH-013`: backend scaffold plan and file boundary |

## UX-005: layout/usability audit wave

| Роль | Статус | Задача |
|---|---|---|
| Regression QA | выдано | `UXQA-001`: общий smoke удобства и технических ошибок |
| Visual System | выдано | `UXVIS-001`: визуальная иерархия, подсветки, сетка |
| Mobile QA | выдано | `UXMOB-001`: mobile 390/430, overflow, тапы, overlay |
| Filters System | выдано | `UXFIL-001`: фильтры, selected tags, reset, старые слои |
| Stories & Motion | выдано | `UXSTO-001`: stories layout/state/rings/viewer |
| Catalog Core | выдано | `UXCAT-001`: карточки, actions, grid/list/map |
| Object Pages | выдано | `UXOBJ-001`: ЖК/застройщик, tabs/modals/back |
| Business | выдано | `UXBUS-001`: бизнес-раздел, filters/cards/views |
| Profile Social | выдано | `UXPRO-001`: профиль, избранное, подписки, рецензии |
| Company Cabinet | выдано | `UXCAB-001`: кабинет, тарифы, CTA, dark/mobile |
